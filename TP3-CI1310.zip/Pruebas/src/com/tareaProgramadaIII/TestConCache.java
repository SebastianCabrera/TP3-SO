package com.tareaProgramadaIII;

/**
 * Created by sebastian on 22/7/2017.
 */
public class TestConCache {
    TestConCache(){}

    void searchDBNombre(String nombre)
    {}
    void searchDBId(String id)
    {}
}
